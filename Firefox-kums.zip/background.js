/*
Open a new tab, and load "my-page.html" into it.
*/
function getDomain(name){
switch (name) {
    case "Translate":
      return "https://translate.google.co.in/";
  case "Input-tools":
	return "https://www.google.com/inputtools/try/";
  case "Dictionary":
	return "http://www.omniglot.com/links/dictionaries.htm";

	}

}

function openMyPage(message) {
var domain = getDomain(message.name);
  chrome.tabs.create({
     "url": chrome.extension.getURL(domain)
   });
}






chrome.runtime.onMessage.addListener(openMyPage);

